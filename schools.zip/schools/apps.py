from django.apps import AppConfig


class SchoolsConfig(AppConfig):
    name = 'schools'
